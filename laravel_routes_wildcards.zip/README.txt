LARAVEL ROUTES AND WILDCARDS - PRACTICAL

Contents
- routes/web.php
- resources/views/*.blade.php

How to use
1. Create a Laravel project if you do not already have one:
   composer create-project laravel/laravel routes-demo
2. Open the project folder.
3. Copy the provided routes/web.php content into your project's routes/web.php.
4. Copy all .blade.php files into resources/views/.
5. Run:
   php artisan serve
6. Open the local URL shown by Laravel, usually http://127.0.0.1:8000.

Example URLs
/                         Home page
/about                    About page
/contact                  Contact page
/hello/Nancy              Wildcard sends Nancy to the view
/student/Nancy/BCA        Two wildcards send name and course
/category                 Optional wildcard uses General
/category/technology      Optional wildcard uses technology
/product/1                Displays Notebook
/product/2                Displays Pen
/product/3                Displays Backpack

Important
- This ZIP contains the files to add to a Laravel project, not a complete Laravel installation.
- If your project already has a layout.blade.php, rename this demo layout and update the @extends(...) lines.
- Laravel's Blade {{ }} syntax escapes displayed values.
- The product example uses sample data only; it does not need a database.
